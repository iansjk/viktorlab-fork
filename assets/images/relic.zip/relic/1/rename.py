import os, sys

for f in os.listdir("."):
    try:
        os.rename(f, f.split("_")[-1])
    except:
        pass